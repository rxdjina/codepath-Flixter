//
//  ViewController.m
//  Flixter
//
//  Created by Rodjina Pierre Louis on 6/16/22.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
