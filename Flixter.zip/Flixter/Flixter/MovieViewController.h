//
//  MovieViewController.h
//  Flixter
//
//  Created by Rodjina Pierre Louis on 6/16/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MovieViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
//@property (nonatomic, strong) UIAlertController *alertControl;
//@property (nonatomic, strong) UIAlertAction *alertAction;

@end

NS_ASSUME_NONNULL_END
