//
//  SceneDelegate.h
//  Flixter
//
//  Created by Rodjina Pierre Louis on 6/16/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

